Simpan logo atau gambar tambahan di folder ini jika nanti diperlukan. Gambar sampul yang sudah tertanam dalam CSS tetap berada di style.css.
